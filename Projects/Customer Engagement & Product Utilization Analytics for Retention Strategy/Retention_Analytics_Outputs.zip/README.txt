Customer Engagement & Product Utilization Analytics outputs
Includes aggregate CSV tables, interactive Plotly chart HTML files, and the Streamlit dashboard source.
The source customer CSV and customer-level records are intentionally excluded.
To reopen a chart, extract the ZIP and open an HTML file from retention_analytics_outputs/figures in a browser.
