from pathlib import Path
import io
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title='Customer Retention Analytics', page_icon='📊', layout='wide')
st.title('Customer Engagement & Product Utilization Analytics')
st.caption('Observational retention analysis • results are associations, not proof of causation')

DATA_PATH = Path('/content/European_Bank.csv')
uploaded = st.sidebar.file_uploader('Upload customer CSV (optional if already uploaded in Colab)', type=['csv'])
try:
    if uploaded is not None:
        df = pd.read_csv(uploaded)
    elif DATA_PATH.exists():
        df = pd.read_csv(DATA_PATH)
    else:
        st.info('Upload the bank customer CSV in the sidebar to begin.')
        st.stop()
except Exception as exc:
    st.error(f'Could not read the CSV: {exc}')
    st.stop()

required = ['CustomerId', 'Geography', 'Age', 'Tenure', 'Balance', 'NumOfProducts', 'HasCrCard', 'IsActiveMember', 'EstimatedSalary', 'Exited']
missing = [c for c in required if c not in df.columns]
if missing:
    st.error(f'Missing required columns: {missing}')
    st.stop()

for col in ['Age', 'Tenure', 'Balance', 'NumOfProducts', 'HasCrCard', 'IsActiveMember', 'EstimatedSalary', 'Exited', 'CustomerId', 'CreditScore', 'Year']:
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')
data = df[df['Exited'].isin([0, 1]) & df['IsActiveMember'].isin([0, 1]) & df['HasCrCard'].isin([0, 1]) & df['NumOfProducts'].isin([1, 2, 3, 4])].copy()
if data.empty:
    st.error('No rows have valid churn, activity, card, and product-count values.')
    st.stop()

st.sidebar.header('Filters')
geographies = sorted(data['Geography'].dropna().astype(str).unique().tolist())
selected_geo = st.sidebar.multiselect('Geography', geographies, default=geographies)
activity_choice = st.sidebar.selectbox('Activity status', ['All', 'Active', 'Inactive'])
product_choices = sorted(data['NumOfProducts'].dropna().astype(int).unique().tolist())
selected_products = st.sidebar.multiselect('Number of products', product_choices, default=product_choices)
card_choice = st.sidebar.selectbox('Credit-card ownership', ['All', 'Has card', 'No card'])
filtered = data[data['Geography'].astype(str).isin(selected_geo) & data['NumOfProducts'].isin(selected_products)].copy()
if activity_choice == 'Active':
    filtered = filtered[filtered['IsActiveMember'] == 1]
elif activity_choice == 'Inactive':
    filtered = filtered[filtered['IsActiveMember'] == 0]
if card_choice == 'Has card':
    filtered = filtered[filtered['HasCrCard'] == 1]
elif card_choice == 'No card':
    filtered = filtered[filtered['HasCrCard'] == 0]
if filtered.empty:
    st.warning('No customers match these filters. Change the filters in the sidebar.')
    st.stop()

churn = float(filtered['Exited'].mean())
retention = 1 - churn
active = int((filtered['IsActiveMember'] == 1).sum())
inactive = int((filtered['IsActiveMember'] == 0).sum())
high_balance_cut = float(data['Balance'].quantile(0.80))

m1, m2, m3, m4 = st.columns(4)
m1.metric('Customers in view', f'{len(filtered):,}')
m2.metric('Observed churn rate', f'{churn:.2%}')
m3.metric('Retention rate', f'{retention:.2%}')
m4.metric('Inactive customers', f'{inactive:,}')

# All dashboard sections live in this single Streamlit file.
tabs = st.tabs(['Overview', 'Engagement', 'Product Count', 'Financial Review', 'Relationship Score', 'Data Quality'])

def grouped_rates(frame, col):
    out = frame.groupby(col, dropna=False)['Exited'].agg(customers='size', churn_rate='mean').reset_index()
    out['retained'] = out['customers'] * (1 - out['churn_rate'])
    out['retention_rate'] = 1 - out['churn_rate']
    return out

with tabs[0]:
    st.subheader('Churn overview')
    st.write(f'Current filtered population: **{len(filtered):,}** of **{len(data):,}** valid customer records.')
    c1, c2 = st.columns(2)
    by_activity = grouped_rates(filtered, 'IsActiveMember')
    by_activity['Activity'] = by_activity['IsActiveMember'].map({0: 'Inactive', 1: 'Active'})
    fig = px.bar(by_activity, x='Activity', y='churn_rate', text='customers', title='Churn by activity', labels={'churn_rate':'Churn rate'})
    fig.update_yaxes(tickformat='.0%', rangemode='tozero')
    c1.plotly_chart(fig, use_container_width=True)
    by_product = grouped_rates(filtered, 'NumOfProducts')
    fig2 = px.bar(by_product, x='NumOfProducts', y='churn_rate', text='customers', title='Churn by product count', labels={'NumOfProducts':'Number of products','churn_rate':'Churn rate'})
    fig2.update_yaxes(tickformat='.0%', rangemode='tozero')
    c2.plotly_chart(fig2, use_container_width=True)
    st.caption('High churn in a group is a signal for investigation, not proof that a particular intervention will work.')

with tabs[1]:
    st.subheader('Engagement analytics')
    engagement = grouped_rates(filtered, 'IsActiveMember')
    engagement['Activity'] = engagement['IsActiveMember'].map({0:'Inactive', 1:'Active'})
    st.dataframe(engagement[['Activity','customers','churn_rate','retention_rate']].style.format({'churn_rate':'{:.2%}','retention_rate':'{:.2%}'}), use_container_width=True)
    rates = dict(zip(engagement['IsActiveMember'], engagement['churn_rate']))
    if 0 in rates and 1 in rates:
        st.write(f'Inactive minus active churn difference: **{(rates[0]-rates[1])*100:+.2f} percentage points**.')
        st.write(f'Inactive-to-active churn-rate ratio: **{(rates[0]/rates[1]):.2f}×**.' if rates[1] else 'Active customer churn rate is zero; ratio is undefined.')
    st.info('IsActiveMember is a coarse activity flag. Transaction recency, frequency, product-level use, and channel engagement are not available.')

with tabs[2]:
    st.subheader('Product-count analysis')
    products = grouped_rates(filtered, 'NumOfProducts').sort_values('NumOfProducts')
    st.dataframe(products[['NumOfProducts','customers','churn_rate','retention_rate']].style.format({'churn_rate':'{:.2%}','retention_rate':'{:.2%}'}), use_container_width=True)
    st.warning('Three- and four-product customers should be investigated separately because their group sizes may be much smaller. Product count is not actual utilization.')

with tabs[3]:
    st.subheader('Financial commitment versus engagement')
    percentile = st.slider('High-balance percentile threshold', min_value=50, max_value=95, value=80, step=5)
    threshold = float(data['Balance'].quantile(percentile/100))
    segment = filtered[(filtered['Balance'] >= threshold) & (filtered['IsActiveMember'] == 0)].copy()
    col1, col2, col3 = st.columns(3)
    col1.metric('Balance cutoff', f'{threshold:,.2f}')
    col2.metric('Inactive high-balance customers', f'{len(segment):,}')
    col3.metric('Segment churn rate', f'{segment["Exited"].mean():.2%}' if len(segment) else 'N/A')
    st.caption('Currency is unspecified. Balance is not profitability or lifetime value. This is a review segment, not an indication of customer intent.')
    show_cols = [c for c in ['CustomerId','Geography','Age','Balance','EstimatedSalary','NumOfProducts','IsActiveMember','HasCrCard','Exited'] if c in segment.columns]
    st.dataframe(segment[show_cols].head(500), use_container_width=True)
    st.download_button('Download filtered high-balance customers (CSV)', segment[show_cols].to_csv(index=False).encode('utf-8'), 'inactive_high_balance_customers.csv', 'text/csv')

with tabs[4]:
    st.subheader('Relationship Strength Index')
    st.caption('Heuristic score out of 100, not a validated prediction of churn.')
    w_activity = st.slider('Activity weight', 0, 100, 50)
    w_product = st.slider('Product breadth weight', 0, 100, 35)
    w_card = st.slider('Card ownership weight', 0, 100, 15)
    total_w = w_activity + w_product + w_card
    if total_w == 0:
        st.warning('At least one weight must be above zero.')
    else:
        score_df = filtered.copy()
        product_component = score_df['NumOfProducts'].clip(upper=2) / 2
        score_df['RelationshipStrengthIndex'] = 100 * (
            (w_activity/total_w) * score_df['IsActiveMember']
            + (w_product/total_w) * product_component
            + (w_card/total_w) * score_df['HasCrCard']
        )
        score_df['ScoreBand'] = pd.cut(score_df['RelationshipStrengthIndex'], [-0.01,25,50,75,100.01], labels=['0–25','26–50','51–75','76–100'], include_lowest=True)
        summary = score_df.groupby('ScoreBand', observed=False).agg(customers=('CustomerId','size'), churn_rate=('Exited','mean'), retention_rate=('Exited',lambda x:1-x.mean())).reset_index()
        st.dataframe(summary.style.format({'churn_rate':'{:.2%}','retention_rate':'{:.2%}'}), use_container_width=True)
        fig3 = px.bar(summary, x='ScoreBand', y='churn_rate', text='customers', title='Observed churn by score band', labels={'churn_rate':'Observed churn rate'})
        fig3.update_yaxes(tickformat='.0%', rangemode='tozero')
        st.plotly_chart(fig3, use_container_width=True)
        st.write('Compare score bands with actual observed churn; do not use the score alone to determine retention priority.')

with tabs[5]:
    st.subheader('Data quality & definitions')
    qrows = [
        ('Rows', len(df)), ('Columns', df.shape[1]), ('Missing cells', int(df.isna().sum().sum())),
        ('Exact duplicate rows', int(df.duplicated().sum())), ('Duplicate CustomerId values', int(df['CustomerId'].duplicated().sum())),
        ('Valid analysis rows', len(data)), ('Invalid / excluded rows', len(df)-len(data)),
    ]
    st.dataframe(pd.DataFrame(qrows, columns=['Check','Result']), use_container_width=True)
    st.markdown('**Definitions**')
    st.markdown('- Churn rate = customers with `Exited = 1` / customers in segment.\n- Retention rate = 1 − churn rate.\n- Product breadth score component = `min(NumOfProducts, 2) / 2`.\n- `CustomerId` is an identifier, not an analytical predictor. Surnames are not shown in exports.')
    st.markdown('**Limitations**')
    st.markdown('- The data is observational; results do not prove causality.\n- Credit-card ownership does not indicate usage.\n- Balance and estimated salary are not profitability measures.\n- A single Year value cannot support year-over-year trends.')
    export_cols = [c for c in ['CustomerId','Geography','Age','Tenure','Balance','EstimatedSalary','NumOfProducts','IsActiveMember','HasCrCard','Exited'] if c in filtered.columns]
    st.download_button('Download current filtered records (CSV)', filtered[export_cols].to_csv(index=False).encode('utf-8'), 'filtered_customer_records.csv', 'text/csv')

st.divider()
st.caption('Suggested next step: test outreach or product-fit changes with a controlled comparison group and monitor subsequent behavior.')
